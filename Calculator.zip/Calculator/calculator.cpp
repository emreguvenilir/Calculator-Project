#include "calculator.h"
#include "ui_calculator.h"

double currVal = 0.0;
bool divTrigger = false;
bool multTrigger = false;
bool addTrigger = false;
bool subTrigger = false;

Calculator::Calculator(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Calculator)
{
    ui->setupUi(this);

    ui->Display->setText(QString::number(currVal));
    QPushButton *buttons[10];

    for(int i=0;i<10;++i)
    {
        QString buttonName = "Button" + QString::number(i);
        buttons[i] = Calculator::findChild<QPushButton *>(buttonName);

        connect(buttons[i],SIGNAL(released()),this,SLOT(NumPressed()));
    }
    //Connections signals to slots
    connect(ui->Add,SIGNAL(released()),this,SLOT(MathButtonPressed()));
    connect(ui->Subtract,SIGNAL(released()),this,SLOT(MathButtonPressed()));
    connect(ui->Multiply,SIGNAL(released()),this,SLOT(MathButtonPressed()));
    connect(ui->Divide,SIGNAL(released()),this,SLOT(MathButtonPressed()));
    connect(ui->Equals,SIGNAL(released()),this,SLOT(EqualButton()));
    connect(ui->Negate,SIGNAL(released()),this,SLOT(ChangeNumberSign()));
    connect(ui->Clear,SIGNAL(released()),this,SLOT(Clear()));
}

Calculator::~Calculator()
{
    delete ui;
}

void Calculator::NumPressed()
{
    QPushButton *button = (QPushButton *)sender();
    QString buttonValue = button->text();
    QString dispValue = ui->Display->text();
    if(dispValue.toDouble()==0 || dispValue.toDouble()==0.0)
    {
        ui->Display->setText(buttonValue);
    }
    else
    {
        QString newVal = dispValue + buttonValue;
        double dblNewVal = newVal.toDouble();

        ui -> Display->setText(QString::number(dblNewVal,'g',16));
    }
}

void Calculator::MathButtonPressed()
{
    divTrigger=false;
    multTrigger=false;
    addTrigger=false;
    subTrigger=false;
    QString displayValue = ui->Display->text();

    currVal = displayValue.toDouble();
    QPushButton *button = (QPushButton *)sender();
    QString buttonValue = button->text();

    if(QString::compare(buttonValue,"/",Qt::CaseInsensitive) == 0)
    {
        divTrigger = true;
    }
    else if(QString::compare(buttonValue,"*",Qt::CaseInsensitive) == 0)
    {
        multTrigger = true;
    }
    else if(QString::compare(buttonValue,"+",Qt::CaseInsensitive) == 0)
    {
        addTrigger = true;
    }
    else
    {
        subTrigger = true;
    }
    ui->Display->setText("");

}
void Calculator::EqualButton()
{
    double solution = 0.0;
    QString displayVal = ui->Display->text();
    double dblDisplayVal = displayVal.toDouble();

    if(addTrigger || subTrigger || multTrigger || divTrigger)
    {
        if(addTrigger)
        {
            solution = currVal + dblDisplayVal;
        }
        else if(subTrigger)
        {
            solution = currVal - dblDisplayVal;
        }
        else if(multTrigger)
        {
            solution = currVal * dblDisplayVal;
        }
        else
        {
            solution = currVal / dblDisplayVal;
        }
    }
    ui->Display->setText(QString::number(solution));
}
void Calculator::ChangeNumberSign()
{
    QString displayValue = ui->Display->text();
    QRegExp reg("[-]?[0-9.]*");
    if(reg.exactMatch(displayValue))
    {
        double dblDisplayValue = displayValue.toDouble();
        double dblDisplayValueSign = dblDisplayValue*-1;
        ui->Display->setText(QString::number(dblDisplayValueSign));
    }
}
void Calculator::Clear()
{
    currVal=0.0;
    divTrigger=false;
    multTrigger=false;
    addTrigger=false;
    subTrigger=false;
    ui->Display->setText(QString::number(0));
}

